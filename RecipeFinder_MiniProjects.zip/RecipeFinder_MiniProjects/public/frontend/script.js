document.addEventListener('DOMContentLoaded', function(){
    const loginBtn = document.getElementById("loginBtn");

    loginBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const loginPageHref = "login.html";
        window.open(loginPageHref, "_blank");

    })
})

document.addEventListener('DOMContentLoaded', function(){
    const aboutBtn = document.getElementById("about");

    aboutBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const aboutPageHref = "about.html";
        window.open(aboutPageHref, "_blank");

    })
})



// document.addEventListener('DOMContentLoaded', function(){
//     const recipeBtn = document.getElementById("recipe");

//     recipeBtn.addEventListener("click",function(){
//         // window.location.href = "login.html"
//         const recipePageHref = "recipe.html";
//         window.open(recipePageHref, "_blank");

//     })
// })


document.addEventListener('DOMContentLoaded', function(){
    const linkedinBtn = document.getElementById('linkedin');

    linkedinBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=AwrjZtKGl79kvu4J0tlXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690306567/RO=10/RU=https%3a%2f%2fwww.linkedin.com%2fuas%2flogin/RK=2/RS=LhGujJhh_VlTAVnTOfwKRLXO63M-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const linkedinBtn = document.getElementById('linkedin2');

    linkedinBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=AwrjZtKGl79kvu4J0tlXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690306567/RO=10/RU=https%3a%2f%2fwww.linkedin.com%2fuas%2flogin/RK=2/RS=LhGujJhh_VlTAVnTOfwKRLXO63M-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const linkedinBtn = document.getElementById('linkedin3');

    linkedinBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=AwrjZtKGl79kvu4J0tlXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690306567/RO=10/RU=https%3a%2f%2fwww.linkedin.com%2fuas%2flogin/RK=2/RS=LhGujJhh_VlTAVnTOfwKRLXO63M-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const linkedinBtn = document.getElementById('linkedin4');

    linkedinBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=AwrjZtKGl79kvu4J0tlXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690306567/RO=10/RU=https%3a%2f%2fwww.linkedin.com%2fuas%2flogin/RK=2/RS=LhGujJhh_VlTAVnTOfwKRLXO63M-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('facebook');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awrg0ISmn79kV2IK3mdXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308646/RO=10/RU=https%3a%2f%2fwww.facebook.com%2flogin.php/RK=2/RS=6gduNMoMtwqvgWY17c2710zfkJY-";
        window.open(linkedinPageHref, "_blank");
    })
})


document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('facebook4');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awrg0ISmn79kV2IK3mdXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308646/RO=10/RU=https%3a%2f%2fwww.facebook.com%2flogin.php/RK=2/RS=6gduNMoMtwqvgWY17c2710zfkJY-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('facebook2');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awrg0ISmn79kV2IK3mdXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308646/RO=10/RU=https%3a%2f%2fwww.facebook.com%2flogin.php/RK=2/RS=6gduNMoMtwqvgWY17c2710zfkJY-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('facebook3');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awrg0ISmn79kV2IK3mdXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308646/RO=10/RU=https%3a%2f%2fwww.facebook.com%2flogin.php/RK=2/RS=6gduNMoMtwqvgWY17c2710zfkJY-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('instagram');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('instagram2');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('instagram3');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('instagram4');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})


document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('twitter');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})

document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('twitter2');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})
document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('twitter3');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})
document.addEventListener('DOMContentLoaded', function(){
    const facebookBtn = document.getElementById('twitter4');

    facebookBtn.addEventListener("click",function(){
        // window.location.href = "login.html"
        const linkedinPageHref = "https://r.search.yahoo.com/_ylt=Awr9_Ur5n79kRNAJ2FVXNyoA;_ylu=Y29sbwNncTEEcG9zAzEEdnRpZANDQVEyNTUyM0hfMQRzZWMDc3I-/RV=2/RE=1690308729/RO=10/RU=https%3a%2f%2faccountscenter.instagram.com%2f/RK=2/RS=GSXQSa3jty6uXCkm5gjHvpOvIkg-";
        window.open(linkedinPageHref, "_blank");
    })
})

let input=document.getElementById('recipe2');
input.addEventListener('click',(e)=>{
        const recipePageHref = "recipefinder.html";
        window.open(recipePageHref, "_self");
    
})


